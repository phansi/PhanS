package com.example.appbookingfilm;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class SignUpForm extends AppCompatActivity {
    private EditText username, password;
    private MaterialButton btn_back_form;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form_signup);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        btn_back_form = findViewById(R.id.btn_back_form);

        btn_back_form.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLoginForm();
            }
        });
    }
    public void openLoginForm(){
        Intent intent = new Intent(this, LoginForm.class);
        startActivity(intent);
    }
}

